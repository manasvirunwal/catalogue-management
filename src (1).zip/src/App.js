import React from "react";
import { BrowserRouter as Router, Switch, Route, Link } from "react-router-dom";
import LoginPage from "./LoginPage";
import CataloguePage from "./CataloguePage";

function App() {
  return (
    <Router>
      <nav>
        <a href="/login" >Login</a>
        <a href="/catalogue" >Catalogue</a>  
      </nav>
      <Switch>
        <Route exact path="/">
          <h1>Welcome to my Catalogue Management Application</h1>
          <p>Please login to access the Catalogue page</p>
        </Route>
        <Route path="/catalogue" component={CataloguePage} />
        <Route path="/login" component={LoginPage} />
      </ Switch>
    </Router>
  );
}

export default App;



// import React from 'react'
// import CataloguePage from './CataloguePage'
// import LoginPage from './LoginPage'


// function App() {
//   return (
//     <div>
   
//       <CataloguePage />
//       <LoginPage />
      
//     </div>
//   )
// }

// export default App
