




import { useState, useEffect } from "react";
import { pie } from "react-chartjs-2";

function CataloguePage() {
    const [products, setProducts] = useState([]);
    const [categories, setCategories] = useState([]);
    const [datasets, setDatasets] = useState([]);

    useEffect(() => {
        fetch("https://fakestoreapi.com/products")
            .then((res) => res.json())
            .then((data) => setProducts(data));

        fetch("https://fakestoreapi.com/products/categories")
            .then((res) => res.json())
            .then((data) => setCategories(data));
    }, []);

    useEffect(() => {
        const data = [];

        categories.forEach((category) => {
            const count = products.filter(
                (product) => product.category === category
            ).length;
            data.push(count);
        });

        setDatasets(data);
    }, [products, categories]);

    function renderChart() {
        if (!datasets) {
            return null; // or some default content
        }

        const data = {
            labels: categories,
            datasets: [
                {
                    label: "Number of products",
                    data: datasets,
                    backgroundColor: [
                        "#ffcd56",
                        "#ff6384",
                        "#36a2eb",
                        "#fd6b19",
                        "#8b7af3",
                        "#fc22ef",
                    ],
                },
            ],
        };

        const options = {
            responsive: true,
            plugins: {
                legend: {
                    position: "top",
                },
                title: {
                    display: true,
                    text: "Number of Products per Category",
                },
            },
        };

        return (
            <div className="chart">
                <pie data={data} options={options} />
            </div>
        );
    }

    function renderProducts() {
        return products.map((product) => {
            return (
                <div className="product" key={product.id}>
                    <h3>{product.title}</h3>
                    <p>
                        {product.description.length > 150
                            ? product.description.slice(0, 150) + "..."
                            : product.description}
                        {product.description.length > 150 && (
                            <button>Read More</button>
                        )}
                    </p>
                    <p>Category: {product.category}</p>
                </div >
            );
        });
    }

    function filterProducts(category) {
        const filteredProducts = products.filter(
            (product) => product.category === category
        );
        console.log(filteredProducts);
    }

    return (
        <div className="catalogue-page">
            <div className="filters">
                <h2>Filter by Category:</h2>
                {categories.map((category) => (
                    <button key={category} onClick={() => filterProducts(category)}>
                        {category}
                    </button>
                ))}
            </div>
            <div className="products">{renderProducts()}</div>
            {categories.length && renderChart()}
        </div>
    );
}

export default CataloguePage;